VITALIS multi-page website

Open index.html to start. Each navigation item opens a separate HTML page. Keep all HTML files and assets in the same folder when testing locally or uploading to a static host.

Image/video filenames referenced by the website:
- NASA_Hunch-Vitalis.png (small header logo/image)
- Team_Picture.jfif (large image on home page)
- Brochure_Side1.png and Brochure_Side2.png
- Gallery_1.png through Gallery_60.png
- Presentation_Video.mp4

The pages will still load without these assets, but missing images/video will appear blank or broken until you add the files with these exact names.

Team role descriptions are draft summaries based on general project contributions. Please adjust them if the team's actual assigned responsibilities are different.
